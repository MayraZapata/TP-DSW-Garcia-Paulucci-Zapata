import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { api } from "../api/client";
import useFetchList from "../hooks/useFetchList";
import useMensaje from "../hooks/useMensaje";
import Mensaje from "../components/Mensaje";

export default function AgendaMedico() {
  const navigate = useNavigate();
  const { rol, usuario } = useAuth();
  const medicosLista = useFetchList("/medicos");
  const diagnosticos = useFetchList("/diagnosticos");
  const aviso = useMensaje();           // avisos de la pantalla
  const avisoModal = useMensaje();      // avisos dentro de la ventana de diagnóstico

  const [matriculaSeleccionada, setMatriculaSeleccionada] = useState("");
  const [turnos, setTurnos] = useState([]);
  const [modalIdAtencion, setModalIdAtencion] = useState(null);
  const [selectDiagnostico, setSelectDiagnostico] = useState("");

  const cargarAgenda = useCallback(async (matricula) => {
    try {
      const data = await api.get(`/consultas/medico/${matricula}`);
      setTurnos(data);
    } catch {
      setTurnos([]);
    }
  }, []);

  useEffect(() => {
    if (rol === "MEDICO" && usuario?.matricula) {
      // eslint-disable-next-line
      setMatriculaSeleccionada(usuario.matricula);
      cargarAgenda(usuario.matricula);
    }
    // eslint-disable-next-line
  }, [rol, usuario]);

  function handleSeleccionMedico(matricula) {
    setMatriculaSeleccionada(matricula);
    if (matricula) cargarAgenda(matricula);
    else setTurnos([]);
  }

  function abrirModal(idAtencion) {
    avisoModal.limpiar();
    setModalIdAtencion(idAtencion);
    setSelectDiagnostico("");
  }

  function cerrarModal() {
    setModalIdAtencion(null);
    setSelectDiagnostico("");
  }

  async function handleGuardarDiagnostico(e) {
    e.preventDefault();
    if (!selectDiagnostico) {
      avisoModal.error("Por favor seleccione un diagnóstico.");
      return;
    }
    try {
      const data = await api.patch(`/consultas/${modalIdAtencion}/diagnostico`, {
        idDiagnostico: Number(selectDiagnostico),
        estado: "atendido",
      });
      cerrarModal();
      aviso.exito(data.message || "Atención y diagnóstico guardados con éxito.");
      cargarAgenda(matriculaSeleccionada);
    } catch (error) {
      avisoModal.error(error.message);
    }
  }

    async function cambiarEstado(idAtencion, nuevoEstado) {
    try {
      await api.patch(`/consultas/${idAtencion}/estado`, { estado: nuevoEstado });
      aviso.exito(`Estado del turno actualizado a: ${nuevoEstado}`);
      cargarAgenda(matriculaSeleccionada);
    } catch (error) {
      aviso.error(error.message);
    }
  }

    return (
      <div className="contenedor-pagina">
        <button className="volver" onClick={() => navigate("/menu")}>Volver</button>
        <h2>Agenda de Turnos</h2>
        <Mensaje mensaje={aviso.mensaje} />

        <div style={{ marginBottom: 20 }}>
          <label htmlFor="selectMedico">Médico:</label>
          {rol === "MEDICO" ? (
            <select id="selectMedico" disabled>
              <option>Dr/a. {usuario?.nombre} {usuario?.apellido}</option>
            </select>
          ) : (
            <select id="selectMedico" value={matriculaSeleccionada} onChange={(e) => handleSeleccionMedico(e.target.value)}>
              <option value="">-- Seleccione Médico --</option>
              {medicosLista.map((m) => (
                <option key={m.matricula} value={m.matricula}>Dr/a. {m.nombre} {m.apellido}</option>
              ))}
            </select>
          )}
        </div>

        <table className="tabla-cards">
          <thead>
            <tr>
              <th>Fecha</th>
              <th>Hora</th>
              <th>Paciente</th>
              <th>DNI</th>
              <th>Estado</th>
              <th>Diagnóstico</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {turnos.length === 0 ? (
              <tr><td colSpan="7">No hay turnos registrados para este médico.</td></tr>
            ) : (
              turnos.map((t) => {
                const fechaStr = t.fechaAtencion ? t.fechaAtencion.split("T")[0] : "N/A";
                return (
                  <tr key={t.idAtencion}>
                    <td data-label="Fecha">{fechaStr}</td>
                    <td data-label="Hora">{t.horaAtencion} hs</td>
                    <td data-label="Paciente">{t.paciente ? `${t.paciente.nombre} ${t.paciente.apellido}` : "N/A"}</td>
                    <td data-label="DNI">{t.paciente?.dni || "N/A"}</td>
                    <td data-label="Estado"><strong>{t.estado ? t.estado.toUpperCase() : "PENDIENTE"}</strong></td>
                    <td data-label="Diagnóstico">{t.diagnostico?.nombreDiagnostico || <em style={{ color: "gray" }}>Sin diagnóstico</em>}</td>
                    <td data-label="Acciones">
                      {t.estado === "pendiente" ? (
                        <>
                          <button 
                            style={{ backgroundColor: "#d4edda", color: "#155724", border: "1px solid #c3e6cb", padding: "6px 12px", borderRadius: "999px", cursor: "pointer" }} 
                            onClick={() => abrirModal(t.idAtencion)}
                          >
                            Marcar Atendido
                          </button>
                          <button 
                            style={{ backgroundColor: "#fff3cd", color: "#856404", border: "1px solid #ffeeba", padding: "6px 12px", borderRadius: "999px", cursor: "pointer" }} 
                            onClick={() => cambiarEstado(t.idAtencion, "ausente")}
                          >
                            Marcar Ausente
                          </button>
                        </>
                      ) : t.estado === "atendido" ? (
                        <button style={{ color: "black", padding: "6px 12px" }} onClick={() => abrirModal(t.idAtencion)}>Editar Diagnóstico</button>
                      ) : (
                        <span style={{ color: "gray" }}>Finalizado</span>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>

        {modalIdAtencion !== null && (
          <div className="modal">
            <div className="modal-content">
              <span className="modal-close" onClick={cerrarModal}>&times;</span>
              <h3>Asignar Diagnóstico</h3>
              <Mensaje mensaje={avisoModal.mensaje} />
              <form onSubmit={handleGuardarDiagnostico}>
                <div className="form-group">
                  <label htmlFor="selectDiagnostico">Seleccionar Diagnóstico:</label>
                  <select id="selectDiagnostico" value={selectDiagnostico} onChange={(e) => setSelectDiagnostico(e.target.value)} required>
                    <option value="">-- Seleccione un Diagnóstico --</option>
                    {diagnosticos.map((d) => (
                      <option key={d.idDiagnostico} value={d.idDiagnostico}>{d.nombreDiagnostico}</option>
                    ))}
                  </select>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginTop: 20 }}>
                  <button type="button" onClick={cerrarModal}>Cancelar</button>
                  <button type="submit">Guardar y Finalizar</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
}